<?php
/**
 * Export to PHP Array plugin for PHPMyAdmin
 * @version 5.2.1
 */

/**
 * Database `library_db`
 */

/* `library_db`.`books` */
$books = array(
);
